# Variables, Constraints, Domains
- Variables: Each empty cell on the board
- Domains: For each cell, a domain is defined as a set of numbers between 1 and 9 except the numbers which are already used in the current row, column or 3 x 3 squares.
- Constraints: No redundant numbers in rows, columns and the 3 x 3 squares.